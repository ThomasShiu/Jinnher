﻿namespace AUTO_SCHE
{
    partial class HEAT_IMPORT_01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HEAT_IMPORT_01));
            this.rTB_hbx3 = new System.Windows.Forms.RichTextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.tb_hbx3 = new System.Windows.Forms.TextBox();
            this.tb_hbx4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.rTB_hbx5 = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.rTB_hbx2 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_hbx5 = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.richtb_status = new System.Windows.Forms.RichTextBox();
            this.rTB_hbx1 = new System.Windows.Forms.RichTextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tb_hbx1 = new System.Windows.Forms.TextBox();
            this.btn_hbx1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.rTB_hbx4 = new System.Windows.Forms.RichTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.rTB_hbx6 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.rTB_hbx8 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.rTB_hbx9 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_stop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.SuspendLayout();
            // 
            // rTB_hbx3
            // 
            this.rTB_hbx3.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx3.Name = "rTB_hbx3";
            this.rTB_hbx3.ReadOnly = true;
            this.rTB_hbx3.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx3.TabIndex = 11;
            this.rTB_hbx3.Text = "";
            // 
            // btn_start
            // 
            this.btn_start.Image = ((System.Drawing.Image)(resources.GetObject("btn_start.Image")));
            this.btn_start.Location = new System.Drawing.Point(275, 486);
            this.btn_start.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(88, 85);
            this.btn_start.TabIndex = 17;
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // tb_hbx3
            // 
            this.tb_hbx3.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx3.Name = "tb_hbx3";
            this.tb_hbx3.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx3.TabIndex = 10;
            this.tb_hbx3.Text = "E:\\HBX_temp\\hbx3\\";
            // 
            // tb_hbx4
            // 
            this.tb_hbx4.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx4.Name = "tb_hbx4";
            this.tb_hbx4.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx4.TabIndex = 12;
            this.tb_hbx4.Text = "E:\\HBX_temp\\hbx4\\";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 22);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "HBX3";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.rTB_hbx3);
            this.tabPage3.Controls.Add(this.tb_hbx3);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(901, 289);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "HBX3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "HBX4";
            // 
            // rTB_hbx5
            // 
            this.rTB_hbx5.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx5.Name = "rTB_hbx5";
            this.rTB_hbx5.ReadOnly = true;
            this.rTB_hbx5.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx5.TabIndex = 15;
            this.rTB_hbx5.Text = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.rTB_hbx2);
            this.tabPage2.Controls.Add(this.tb_hbx2);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(901, 289);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "HBX2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // rTB_hbx2
            // 
            this.rTB_hbx2.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx2.Name = "rTB_hbx2";
            this.rTB_hbx2.ReadOnly = true;
            this.rTB_hbx2.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx2.TabIndex = 9;
            this.rTB_hbx2.Text = "";
            // 
            // tb_hbx2
            // 
            this.tb_hbx2.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx2.Name = "tb_hbx2";
            this.tb_hbx2.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx2.TabIndex = 8;
            this.tb_hbx2.Text = "E:\\HBX_temp\\hbx2\\";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "HBX2";
            // 
            // tb_hbx5
            // 
            this.tb_hbx5.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx5.Name = "tb_hbx5";
            this.tb_hbx5.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx5.TabIndex = 14;
            this.tb_hbx5.Text = "E:\\HBX_temp\\hbx5\\";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 603);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(968, 22);
            this.statusStrip1.TabIndex = 21;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // richtb_status
            // 
            this.richtb_status.Location = new System.Drawing.Point(16, 352);
            this.richtb_status.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richtb_status.Name = "richtb_status";
            this.richtb_status.ReadOnly = true;
            this.richtb_status.Size = new System.Drawing.Size(903, 125);
            this.richtb_status.TabIndex = 20;
            this.richtb_status.Text = "";
            // 
            // rTB_hbx1
            // 
            this.rTB_hbx1.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx1.Name = "rTB_hbx1";
            this.rTB_hbx1.ReadOnly = true;
            this.rTB_hbx1.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx1.TabIndex = 5;
            this.rTB_hbx1.Text = "";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(16, 28);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(909, 318);
            this.tabControl1.TabIndex = 19;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.rTB_hbx1);
            this.tabPage1.Controls.Add(this.tb_hbx1);
            this.tabPage1.Controls.Add(this.btn_hbx1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(901, 289);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "HBX1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tb_hbx1
            // 
            this.tb_hbx1.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx1.Name = "tb_hbx1";
            this.tb_hbx1.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx1.TabIndex = 4;
            this.tb_hbx1.Text = "E:\\HBX_temp\\hbx1\\";
            // 
            // btn_hbx1
            // 
            this.btn_hbx1.AutoSize = true;
            this.btn_hbx1.Location = new System.Drawing.Point(8, 22);
            this.btn_hbx1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.btn_hbx1.Name = "btn_hbx1";
            this.btn_hbx1.Size = new System.Drawing.Size(43, 15);
            this.btn_hbx1.TabIndex = 3;
            this.btn_hbx1.Text = "HBX1";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.rTB_hbx4);
            this.tabPage4.Controls.Add(this.tb_hbx4);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(901, 289);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "HBX4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // rTB_hbx4
            // 
            this.rTB_hbx4.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx4.Name = "rTB_hbx4";
            this.rTB_hbx4.ReadOnly = true;
            this.rTB_hbx4.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx4.TabIndex = 13;
            this.rTB_hbx4.Text = "";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.rTB_hbx5);
            this.tabPage5.Controls.Add(this.tb_hbx5);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(901, 289);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "HBX5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 22);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "HBX5";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.rTB_hbx6);
            this.tabPage6.Controls.Add(this.tb_hbx6);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(901, 289);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "HBX6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // rTB_hbx6
            // 
            this.rTB_hbx6.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx6.Name = "rTB_hbx6";
            this.rTB_hbx6.ReadOnly = true;
            this.rTB_hbx6.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx6.TabIndex = 17;
            this.rTB_hbx6.Text = "";
            // 
            // tb_hbx6
            // 
            this.tb_hbx6.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx6.Name = "tb_hbx6";
            this.tb_hbx6.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx6.TabIndex = 16;
            this.tb_hbx6.Text = "E:\\HBX_temp\\hbx6\\";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "HBX5";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.rTB_hbx8);
            this.tabPage8.Controls.Add(this.tb_hbx8);
            this.tabPage8.Controls.Add(this.label8);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(901, 289);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "HBX8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // rTB_hbx8
            // 
            this.rTB_hbx8.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx8.Name = "rTB_hbx8";
            this.rTB_hbx8.ReadOnly = true;
            this.rTB_hbx8.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx8.TabIndex = 17;
            this.rTB_hbx8.Text = "";
            // 
            // tb_hbx8
            // 
            this.tb_hbx8.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx8.Name = "tb_hbx8";
            this.tb_hbx8.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx8.TabIndex = 16;
            this.tb_hbx8.Text = "E:\\HBX_temp\\hbx8\\";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 22);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "HBX5";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.rTB_hbx9);
            this.tabPage9.Controls.Add(this.tb_hbx9);
            this.tabPage9.Controls.Add(this.label9);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(901, 289);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "HBX9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // rTB_hbx9
            // 
            this.rTB_hbx9.Location = new System.Drawing.Point(11, 56);
            this.rTB_hbx9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rTB_hbx9.Name = "rTB_hbx9";
            this.rTB_hbx9.ReadOnly = true;
            this.rTB_hbx9.Size = new System.Drawing.Size(879, 220);
            this.rTB_hbx9.TabIndex = 17;
            this.rTB_hbx9.Text = "";
            // 
            // tb_hbx9
            // 
            this.tb_hbx9.Location = new System.Drawing.Point(64, 16);
            this.tb_hbx9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_hbx9.Name = "tb_hbx9";
            this.tb_hbx9.Size = new System.Drawing.Size(537, 25);
            this.tb_hbx9.TabIndex = 16;
            this.tb_hbx9.Text = "E:\\HBX_temp\\hbx9\\";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 22);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 15);
            this.label9.TabIndex = 15;
            this.label9.Text = "HBX5";
            // 
            // btn_stop
            // 
            this.btn_stop.Image = ((System.Drawing.Image)(resources.GetObject("btn_stop.Image")));
            this.btn_stop.Location = new System.Drawing.Point(533, 486);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(91, 85);
            this.btn_stop.TabIndex = 18;
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "每秒抓取目錄內之檔案並匯入資料庫中";
            // 
            // timer1
            // 
            this.timer1.Interval = 60000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(894, 539);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 60);
            this.button1.TabIndex = 22;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HEAT_IMPORT_01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 625);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.richtb_status);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "HEAT_IMPORT_01";
            this.Text = "熱處理爐溫度收集程式";
            this.Load += new System.EventHandler(this.HEAT_IMPORT_01_Load);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rTB_hbx3;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.TextBox tb_hbx3;
        private System.Windows.Forms.TextBox tb_hbx4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rTB_hbx5;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox rTB_hbx2;
        private System.Windows.Forms.TextBox tb_hbx2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_hbx5;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.RichTextBox richtb_status;
        private System.Windows.Forms.RichTextBox rTB_hbx1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox tb_hbx1;
        private System.Windows.Forms.Label btn_hbx1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.RichTextBox rTB_hbx4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.RichTextBox rTB_hbx6;
        private System.Windows.Forms.TextBox tb_hbx6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.RichTextBox rTB_hbx8;
        private System.Windows.Forms.TextBox tb_hbx8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.RichTextBox rTB_hbx9;
        private System.Windows.Forms.TextBox tb_hbx9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}