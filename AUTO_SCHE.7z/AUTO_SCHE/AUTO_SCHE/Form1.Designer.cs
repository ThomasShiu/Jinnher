﻿namespace AUTO_SCHE
{
    partial class Main_win
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_win));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.熱處理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自動溫度收集ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xDF資料收集ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bBI出貨ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sQL轉ORACLE排程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bBI檢驗報告檢查ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模工具異動ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.領用繳回轉檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.電子郵件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.寄送通知ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.寄送通知排程JHERPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.掃描郵件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.盤元相關ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.盤元掃描轉檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.轉檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelToPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelToPDF電鍍ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelToPDF成型ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.中鋼轉檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sOE3訂單下載ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自動掃描郵件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.熱處理ToolStripMenuItem,
            this.bBI出貨ToolStripMenuItem,
            this.模工具異動ToolStripMenuItem,
            this.電子郵件ToolStripMenuItem,
            this.盤元相關ToolStripMenuItem,
            this.轉檔ToolStripMenuItem,
            this.中鋼轉檔ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(717, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 熱處理ToolStripMenuItem
            // 
            this.熱處理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.自動溫度收集ToolStripMenuItem,
            this.xDF資料收集ToolStripMenuItem});
            this.熱處理ToolStripMenuItem.Name = "熱處理ToolStripMenuItem";
            this.熱處理ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.熱處理ToolStripMenuItem.Text = "熱處理";
            // 
            // 自動溫度收集ToolStripMenuItem
            // 
            this.自動溫度收集ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.chart_curve;
            this.自動溫度收集ToolStripMenuItem.Name = "自動溫度收集ToolStripMenuItem";
            this.自動溫度收集ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.自動溫度收集ToolStripMenuItem.Text = "自動溫度收集";
            this.自動溫度收集ToolStripMenuItem.Click += new System.EventHandler(this.自動溫度收集ToolStripMenuItem_Click);
            // 
            // xDF資料收集ToolStripMenuItem
            // 
            this.xDF資料收集ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.chart_curve;
            this.xDF資料收集ToolStripMenuItem.Name = "xDF資料收集ToolStripMenuItem";
            this.xDF資料收集ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.xDF資料收集ToolStripMenuItem.Text = "XDF資料收集";
            this.xDF資料收集ToolStripMenuItem.Click += new System.EventHandler(this.xDF資料收集ToolStripMenuItem_Click);
            // 
            // bBI出貨ToolStripMenuItem
            // 
            this.bBI出貨ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sQL轉ORACLE排程ToolStripMenuItem,
            this.bBI檢驗報告檢查ToolStripMenuItem});
            this.bBI出貨ToolStripMenuItem.Name = "bBI出貨ToolStripMenuItem";
            this.bBI出貨ToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.bBI出貨ToolStripMenuItem.Text = "BBI相關";
            // 
            // sQL轉ORACLE排程ToolStripMenuItem
            // 
            this.sQL轉ORACLE排程ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.clock;
            this.sQL轉ORACLE排程ToolStripMenuItem.Name = "sQL轉ORACLE排程ToolStripMenuItem";
            this.sQL轉ORACLE排程ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sQL轉ORACLE排程ToolStripMenuItem.Text = "SQL轉ORACLE排程";
            this.sQL轉ORACLE排程ToolStripMenuItem.Click += new System.EventHandler(this.sQL轉ORACLE排程ToolStripMenuItem_Click);
            // 
            // bBI檢驗報告檢查ToolStripMenuItem
            // 
            this.bBI檢驗報告檢查ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.file_extension_pdf1;
            this.bBI檢驗報告檢查ToolStripMenuItem.Name = "bBI檢驗報告檢查ToolStripMenuItem";
            this.bBI檢驗報告檢查ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bBI檢驗報告檢查ToolStripMenuItem.Text = "BBI檢驗報告檢查";
            this.bBI檢驗報告檢查ToolStripMenuItem.Click += new System.EventHandler(this.bBI檢驗報告檢查ToolStripMenuItem_Click);
            // 
            // 模工具異動ToolStripMenuItem
            // 
            this.模工具異動ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.領用繳回轉檔ToolStripMenuItem});
            this.模工具異動ToolStripMenuItem.Name = "模工具異動ToolStripMenuItem";
            this.模工具異動ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.模工具異動ToolStripMenuItem.Text = "模工具異動";
            // 
            // 領用繳回轉檔ToolStripMenuItem
            // 
            this.領用繳回轉檔ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.clock;
            this.領用繳回轉檔ToolStripMenuItem.Name = "領用繳回轉檔ToolStripMenuItem";
            this.領用繳回轉檔ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.領用繳回轉檔ToolStripMenuItem.Text = "領用繳回轉檔";
            this.領用繳回轉檔ToolStripMenuItem.Click += new System.EventHandler(this.領用繳回轉檔ToolStripMenuItem_Click);
            // 
            // 電子郵件ToolStripMenuItem
            // 
            this.電子郵件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.寄送通知ToolStripMenuItem,
            this.寄送通知排程JHERPToolStripMenuItem,
            this.掃描郵件ToolStripMenuItem,
            this.自動掃描郵件ToolStripMenuItem});
            this.電子郵件ToolStripMenuItem.Name = "電子郵件ToolStripMenuItem";
            this.電子郵件ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.電子郵件ToolStripMenuItem.Text = "電子郵件";
            // 
            // 寄送通知ToolStripMenuItem
            // 
            this.寄送通知ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.email;
            this.寄送通知ToolStripMenuItem.Name = "寄送通知ToolStripMenuItem";
            this.寄送通知ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.寄送通知ToolStripMenuItem.Text = "寄送通知排程";
            this.寄送通知ToolStripMenuItem.Click += new System.EventHandler(this.寄送通知ToolStripMenuItem_Click);
            // 
            // 寄送通知排程JHERPToolStripMenuItem
            // 
            this.寄送通知排程JHERPToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.email;
            this.寄送通知排程JHERPToolStripMenuItem.Name = "寄送通知排程JHERPToolStripMenuItem";
            this.寄送通知排程JHERPToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.寄送通知排程JHERPToolStripMenuItem.Text = "寄送通知排程JHERP";
            this.寄送通知排程JHERPToolStripMenuItem.Click += new System.EventHandler(this.寄送通知排程JHERPToolStripMenuItem_Click);
            // 
            // 掃描郵件ToolStripMenuItem
            // 
            this.掃描郵件ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.email;
            this.掃描郵件ToolStripMenuItem.Name = "掃描郵件ToolStripMenuItem";
            this.掃描郵件ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.掃描郵件ToolStripMenuItem.Text = "掃描郵件";
            this.掃描郵件ToolStripMenuItem.Click += new System.EventHandler(this.掃描郵件ToolStripMenuItem_Click);
            // 
            // 盤元相關ToolStripMenuItem
            // 
            this.盤元相關ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.盤元掃描轉檔ToolStripMenuItem});
            this.盤元相關ToolStripMenuItem.Name = "盤元相關ToolStripMenuItem";
            this.盤元相關ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.盤元相關ToolStripMenuItem.Text = "盤元相關";
            // 
            // 盤元掃描轉檔ToolStripMenuItem
            // 
            this.盤元掃描轉檔ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.clock;
            this.盤元掃描轉檔ToolStripMenuItem.Name = "盤元掃描轉檔ToolStripMenuItem";
            this.盤元掃描轉檔ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.盤元掃描轉檔ToolStripMenuItem.Text = "盤元掃描轉檔";
            this.盤元掃描轉檔ToolStripMenuItem.Click += new System.EventHandler(this.盤元掃描轉檔ToolStripMenuItem_Click);
            // 
            // 轉檔ToolStripMenuItem
            // 
            this.轉檔ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.excelToPDFToolStripMenuItem,
            this.excelToPDF電鍍ToolStripMenuItem,
            this.excelToPDF成型ToolStripMenuItem});
            this.轉檔ToolStripMenuItem.Name = "轉檔ToolStripMenuItem";
            this.轉檔ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.轉檔ToolStripMenuItem.Text = "轉檔";
            // 
            // excelToPDFToolStripMenuItem
            // 
            this.excelToPDFToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.file_extension_pdf1;
            this.excelToPDFToolStripMenuItem.Name = "excelToPDFToolStripMenuItem";
            this.excelToPDFToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.excelToPDFToolStripMenuItem.Text = "ExcelToPDF-熱處理";
            this.excelToPDFToolStripMenuItem.Click += new System.EventHandler(this.excelToPDFToolStripMenuItem_Click);
            // 
            // excelToPDF電鍍ToolStripMenuItem
            // 
            this.excelToPDF電鍍ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.file_extension_pdf1;
            this.excelToPDF電鍍ToolStripMenuItem.Name = "excelToPDF電鍍ToolStripMenuItem";
            this.excelToPDF電鍍ToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.excelToPDF電鍍ToolStripMenuItem.Text = "ExcelToPDF-電鍍";
            this.excelToPDF電鍍ToolStripMenuItem.Click += new System.EventHandler(this.excelToPDF電鍍ToolStripMenuItem_Click);
            // 
            // excelToPDF成型ToolStripMenuItem
            // 
            this.excelToPDF成型ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.file_extension_pdf1;
            this.excelToPDF成型ToolStripMenuItem.Name = "excelToPDF成型ToolStripMenuItem";
            this.excelToPDF成型ToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.excelToPDF成型ToolStripMenuItem.Text = "ExcelToPDF-成型";
            this.excelToPDF成型ToolStripMenuItem.Click += new System.EventHandler(this.excelToPDF成型ToolStripMenuItem_Click);
            // 
            // 中鋼轉檔ToolStripMenuItem
            // 
            this.中鋼轉檔ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sOE3訂單下載ToolStripMenuItem});
            this.中鋼轉檔ToolStripMenuItem.Name = "中鋼轉檔ToolStripMenuItem";
            this.中鋼轉檔ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.中鋼轉檔ToolStripMenuItem.Text = "中鋼轉檔";
            // 
            // sOE3訂單下載ToolStripMenuItem
            // 
            this.sOE3訂單下載ToolStripMenuItem.Name = "sOE3訂單下載ToolStripMenuItem";
            this.sOE3訂單下載ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.sOE3訂單下載ToolStripMenuItem.Text = "SOE3-訂單下載";
            this.sOE3訂單下載ToolStripMenuItem.Click += new System.EventHandler(this.sOE3訂單下載ToolStripMenuItem_Click);
            // 
            // 自動掃描郵件ToolStripMenuItem
            // 
            this.自動掃描郵件ToolStripMenuItem.Image = global::AUTO_SCHE.Properties.Resources.email;
            this.自動掃描郵件ToolStripMenuItem.Name = "自動掃描郵件ToolStripMenuItem";
            this.自動掃描郵件ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.自動掃描郵件ToolStripMenuItem.Text = "自動掃描郵件";
            this.自動掃描郵件ToolStripMenuItem.Click += new System.EventHandler(this.自動掃描郵件ToolStripMenuItem_Click);
            // 
            // Main_win
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(717, 444);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main_win";
            this.Text = "自動工作排程";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_win_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 熱處理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bBI出貨ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sQL轉ORACLE排程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 自動溫度收集ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 模工具異動ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 領用繳回轉檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 電子郵件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 寄送通知ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bBI檢驗報告檢查ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 盤元相關ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 盤元掃描轉檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xDF資料收集ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 寄送通知排程JHERPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 轉檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excelToPDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excelToPDF電鍍ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excelToPDF成型ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 中鋼轉檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sOE3訂單下載ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 掃描郵件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 自動掃描郵件ToolStripMenuItem;
    }
}

