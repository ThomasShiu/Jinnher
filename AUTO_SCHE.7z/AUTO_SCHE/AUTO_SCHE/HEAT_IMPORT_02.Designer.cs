﻿namespace AUTO_SCHE
{
    partial class HEAT_IMPORT_02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HEAT_IMPORT_02));
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.b_hbx6 = new System.Windows.Forms.Button();
            this.L_hbx6 = new System.Windows.Forms.Label();
            this.rTB_hbx6 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rTB_hbx3 = new System.Windows.Forms.RichTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.b_hbx5 = new System.Windows.Forms.Button();
            this.L_hbx5 = new System.Windows.Forms.Label();
            this.rTB_hbx5 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rTB_hbx1 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx1 = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.b_hbx8 = new System.Windows.Forms.Button();
            this.L_hbx8 = new System.Windows.Forms.Label();
            this.rTB_hbx8 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rTB_hbx9 = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_start = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.L_hbx9 = new System.Windows.Forms.Label();
            this.tb_hbx9 = new System.Windows.Forms.TextBox();
            this.rTB_hbx4 = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.b_hbx2 = new System.Windows.Forms.Button();
            this.L_hbx2 = new System.Windows.Forms.Label();
            this.rTB_hbx2 = new System.Windows.Forms.RichTextBox();
            this.tb_hbx2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.b_hbx3 = new System.Windows.Forms.Button();
            this.L_hbx3 = new System.Windows.Forms.Label();
            this.tb_hbx3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_hbx4 = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.b_hbx4 = new System.Windows.Forms.Button();
            this.L_hbx4 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.b_hbx1 = new System.Windows.Forms.Button();
            this.L_hbx1 = new System.Windows.Forms.Label();
            this.btn_hbx1 = new System.Windows.Forms.Label();
            this.richtb_status = new System.Windows.Forms.RichTextBox();
            this.b_hbx9 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.b_stc1 = new System.Windows.Forms.Button();
            this.L_stc1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rTB_stc1 = new System.Windows.Forms.RichTextBox();
            this.tb_STC1 = new System.Windows.Forms.TextBox();
            this.btn_stop = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_clear1 = new System.Windows.Forms.Button();
            this.btn_clear2 = new System.Windows.Forms.Button();
            this.TB_count = new System.Windows.Forms.TextBox();
            this.tabPage6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.b_hbx9.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.b_hbx6);
            this.tabPage6.Controls.Add(this.L_hbx6);
            this.tabPage6.Controls.Add(this.rTB_hbx6);
            this.tabPage6.Controls.Add(this.tb_hbx6);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(674, 228);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "HBX6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // b_hbx6
            // 
            this.b_hbx6.Location = new System.Drawing.Point(593, 12);
            this.b_hbx6.Name = "b_hbx6";
            this.b_hbx6.Size = new System.Drawing.Size(75, 23);
            this.b_hbx6.TabIndex = 19;
            this.b_hbx6.Text = "立即執行";
            this.b_hbx6.UseVisualStyleBackColor = true;
            this.b_hbx6.Click += new System.EventHandler(this.b_hbx6_Click);
            // 
            // L_hbx6
            // 
            this.L_hbx6.AutoSize = true;
            this.L_hbx6.Location = new System.Drawing.Point(458, 18);
            this.L_hbx6.Name = "L_hbx6";
            this.L_hbx6.Size = new System.Drawing.Size(18, 12);
            this.L_hbx6.TabIndex = 18;
            this.L_hbx6.Text = "L6";
            // 
            // rTB_hbx6
            // 
            this.rTB_hbx6.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx6.Name = "rTB_hbx6";
            this.rTB_hbx6.ReadOnly = true;
            this.rTB_hbx6.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx6.TabIndex = 17;
            this.rTB_hbx6.Text = "";
            // 
            // tb_hbx6
            // 
            this.tb_hbx6.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx6.Name = "tb_hbx6";
            this.tb_hbx6.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx6.TabIndex = 16;
            this.tb_hbx6.Text = "E:\\HBX_temp\\hbx6xdf\\";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "HBX6";
            // 
            // rTB_hbx3
            // 
            this.rTB_hbx3.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx3.Name = "rTB_hbx3";
            this.rTB_hbx3.ReadOnly = true;
            this.rTB_hbx3.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx3.TabIndex = 11;
            this.rTB_hbx3.Text = "";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.b_hbx5);
            this.tabPage5.Controls.Add(this.L_hbx5);
            this.tabPage5.Controls.Add(this.rTB_hbx5);
            this.tabPage5.Controls.Add(this.tb_hbx5);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(674, 228);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "HBX5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // b_hbx5
            // 
            this.b_hbx5.Location = new System.Drawing.Point(593, 12);
            this.b_hbx5.Name = "b_hbx5";
            this.b_hbx5.Size = new System.Drawing.Size(75, 23);
            this.b_hbx5.TabIndex = 17;
            this.b_hbx5.Text = "立即執行";
            this.b_hbx5.UseVisualStyleBackColor = true;
            this.b_hbx5.Click += new System.EventHandler(this.b_hbx5_Click);
            // 
            // L_hbx5
            // 
            this.L_hbx5.AutoSize = true;
            this.L_hbx5.Location = new System.Drawing.Point(458, 18);
            this.L_hbx5.Name = "L_hbx5";
            this.L_hbx5.Size = new System.Drawing.Size(18, 12);
            this.L_hbx5.TabIndex = 16;
            this.L_hbx5.Text = "L5";
            // 
            // rTB_hbx5
            // 
            this.rTB_hbx5.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx5.Name = "rTB_hbx5";
            this.rTB_hbx5.ReadOnly = true;
            this.rTB_hbx5.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx5.TabIndex = 15;
            this.rTB_hbx5.Text = "";
            // 
            // tb_hbx5
            // 
            this.tb_hbx5.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx5.Name = "tb_hbx5";
            this.tb_hbx5.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx5.TabIndex = 14;
            this.tb_hbx5.Text = "E:\\HBX_temp\\hbx5xdf\\";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "HBX5";
            // 
            // rTB_hbx1
            // 
            this.rTB_hbx1.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx1.Name = "rTB_hbx1";
            this.rTB_hbx1.ReadOnly = true;
            this.rTB_hbx1.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx1.TabIndex = 5;
            this.rTB_hbx1.Text = "";
            // 
            // tb_hbx1
            // 
            this.tb_hbx1.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx1.Name = "tb_hbx1";
            this.tb_hbx1.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx1.TabIndex = 4;
            this.tb_hbx1.Text = "E:\\HBX_temp\\hbx1xdf\\";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.b_hbx8);
            this.tabPage8.Controls.Add(this.L_hbx8);
            this.tabPage8.Controls.Add(this.rTB_hbx8);
            this.tabPage8.Controls.Add(this.tb_hbx8);
            this.tabPage8.Controls.Add(this.label8);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(674, 228);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "HBX8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // b_hbx8
            // 
            this.b_hbx8.Location = new System.Drawing.Point(593, 12);
            this.b_hbx8.Name = "b_hbx8";
            this.b_hbx8.Size = new System.Drawing.Size(75, 23);
            this.b_hbx8.TabIndex = 19;
            this.b_hbx8.Text = "立即執行";
            this.b_hbx8.UseVisualStyleBackColor = true;
            this.b_hbx8.Click += new System.EventHandler(this.b_hbx8_Click);
            // 
            // L_hbx8
            // 
            this.L_hbx8.AutoSize = true;
            this.L_hbx8.Location = new System.Drawing.Point(458, 18);
            this.L_hbx8.Name = "L_hbx8";
            this.L_hbx8.Size = new System.Drawing.Size(18, 12);
            this.L_hbx8.TabIndex = 18;
            this.L_hbx8.Text = "L8";
            // 
            // rTB_hbx8
            // 
            this.rTB_hbx8.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx8.Name = "rTB_hbx8";
            this.rTB_hbx8.ReadOnly = true;
            this.rTB_hbx8.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx8.TabIndex = 17;
            this.rTB_hbx8.Text = "";
            // 
            // tb_hbx8
            // 
            this.tb_hbx8.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx8.Name = "tb_hbx8";
            this.tb_hbx8.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx8.TabIndex = 16;
            this.tb_hbx8.Text = "E:\\HBX_temp\\hbx8xdf\\";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "HBX8";
            // 
            // rTB_hbx9
            // 
            this.rTB_hbx9.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx9.Name = "rTB_hbx9";
            this.rTB_hbx9.ReadOnly = true;
            this.rTB_hbx9.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx9.TabIndex = 17;
            this.rTB_hbx9.Text = "";
            // 
            // timer1
            // 
            this.timer1.Interval = 60000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_start
            // 
            this.btn_start.Image = ((System.Drawing.Image)(resources.GetObject("btn_start.Image")));
            this.btn_start.Location = new System.Drawing.Point(206, 386);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(66, 68);
            this.btn_start.TabIndex = 23;
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(232, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 12);
            this.label1.TabIndex = 22;
            this.label1.Text = "分鐘抓取目錄內之檔案並匯入資料庫中";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 12);
            this.label9.TabIndex = 15;
            this.label9.Text = "HBX9";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.button8);
            this.tabPage9.Controls.Add(this.L_hbx9);
            this.tabPage9.Controls.Add(this.rTB_hbx9);
            this.tabPage9.Controls.Add(this.tb_hbx9);
            this.tabPage9.Controls.Add(this.label9);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(674, 228);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "HBX9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(593, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 19;
            this.button8.Text = "立即執行";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // L_hbx9
            // 
            this.L_hbx9.AutoSize = true;
            this.L_hbx9.Location = new System.Drawing.Point(458, 18);
            this.L_hbx9.Name = "L_hbx9";
            this.L_hbx9.Size = new System.Drawing.Size(18, 12);
            this.L_hbx9.TabIndex = 18;
            this.L_hbx9.Text = "L9";
            // 
            // tb_hbx9
            // 
            this.tb_hbx9.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx9.Name = "tb_hbx9";
            this.tb_hbx9.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx9.TabIndex = 16;
            this.tb_hbx9.Text = "E:\\HBX_temp\\hbx9xdf\\";
            // 
            // rTB_hbx4
            // 
            this.rTB_hbx4.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx4.Name = "rTB_hbx4";
            this.rTB_hbx4.ReadOnly = true;
            this.rTB_hbx4.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx4.TabIndex = 13;
            this.rTB_hbx4.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "HBX4";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.b_hbx2);
            this.tabPage2.Controls.Add(this.L_hbx2);
            this.tabPage2.Controls.Add(this.rTB_hbx2);
            this.tabPage2.Controls.Add(this.tb_hbx2);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(674, 228);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "HBX2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // b_hbx2
            // 
            this.b_hbx2.Location = new System.Drawing.Point(593, 12);
            this.b_hbx2.Name = "b_hbx2";
            this.b_hbx2.Size = new System.Drawing.Size(75, 23);
            this.b_hbx2.TabIndex = 11;
            this.b_hbx2.Text = "立即執行";
            this.b_hbx2.UseVisualStyleBackColor = true;
            this.b_hbx2.Click += new System.EventHandler(this.b_hbx2_Click);
            // 
            // L_hbx2
            // 
            this.L_hbx2.AutoSize = true;
            this.L_hbx2.Location = new System.Drawing.Point(458, 18);
            this.L_hbx2.Name = "L_hbx2";
            this.L_hbx2.Size = new System.Drawing.Size(18, 12);
            this.L_hbx2.TabIndex = 10;
            this.L_hbx2.Text = "L2";
            // 
            // rTB_hbx2
            // 
            this.rTB_hbx2.Location = new System.Drawing.Point(8, 45);
            this.rTB_hbx2.Name = "rTB_hbx2";
            this.rTB_hbx2.ReadOnly = true;
            this.rTB_hbx2.Size = new System.Drawing.Size(660, 177);
            this.rTB_hbx2.TabIndex = 9;
            this.rTB_hbx2.Text = "";
            // 
            // tb_hbx2
            // 
            this.tb_hbx2.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx2.Name = "tb_hbx2";
            this.tb_hbx2.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx2.TabIndex = 8;
            this.tb_hbx2.Text = "E:\\HBX_temp\\hbx2xdf\\";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "HBX2";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.b_hbx3);
            this.tabPage3.Controls.Add(this.L_hbx3);
            this.tabPage3.Controls.Add(this.rTB_hbx3);
            this.tabPage3.Controls.Add(this.tb_hbx3);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(674, 228);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "HBX3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // b_hbx3
            // 
            this.b_hbx3.Location = new System.Drawing.Point(593, 12);
            this.b_hbx3.Name = "b_hbx3";
            this.b_hbx3.Size = new System.Drawing.Size(75, 23);
            this.b_hbx3.TabIndex = 13;
            this.b_hbx3.Text = "立即執行";
            this.b_hbx3.UseVisualStyleBackColor = true;
            this.b_hbx3.Click += new System.EventHandler(this.b_hbx3_Click);
            // 
            // L_hbx3
            // 
            this.L_hbx3.AutoSize = true;
            this.L_hbx3.Location = new System.Drawing.Point(458, 18);
            this.L_hbx3.Name = "L_hbx3";
            this.L_hbx3.Size = new System.Drawing.Size(18, 12);
            this.L_hbx3.TabIndex = 12;
            this.L_hbx3.Text = "L3";
            // 
            // tb_hbx3
            // 
            this.tb_hbx3.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx3.Name = "tb_hbx3";
            this.tb_hbx3.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx3.TabIndex = 10;
            this.tb_hbx3.Text = "E:\\HBX_temp\\hbx3xdf\\";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "HBX3";
            // 
            // tb_hbx4
            // 
            this.tb_hbx4.Location = new System.Drawing.Point(48, 13);
            this.tb_hbx4.Name = "tb_hbx4";
            this.tb_hbx4.Size = new System.Drawing.Size(404, 22);
            this.tb_hbx4.TabIndex = 12;
            this.tb_hbx4.Text = "E:\\HBX_temp\\hbx4xdf\\";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.b_hbx4);
            this.tabPage4.Controls.Add(this.L_hbx4);
            this.tabPage4.Controls.Add(this.rTB_hbx4);
            this.tabPage4.Controls.Add(this.tb_hbx4);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(674, 228);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "HBX4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // b_hbx4
            // 
            this.b_hbx4.Location = new System.Drawing.Point(593, 12);
            this.b_hbx4.Name = "b_hbx4";
            this.b_hbx4.Size = new System.Drawing.Size(75, 23);
            this.b_hbx4.TabIndex = 15;
            this.b_hbx4.Text = "立即執行";
            this.b_hbx4.UseVisualStyleBackColor = true;
            this.b_hbx4.Click += new System.EventHandler(this.b_hbx4_Click);
            // 
            // L_hbx4
            // 
            this.L_hbx4.AutoSize = true;
            this.L_hbx4.Location = new System.Drawing.Point(458, 18);
            this.L_hbx4.Name = "L_hbx4";
            this.L_hbx4.Size = new System.Drawing.Size(18, 12);
            this.L_hbx4.TabIndex = 14;
            this.L_hbx4.Text = "L4";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 461);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(709, 22);
            this.statusStrip1.TabIndex = 27;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.b_hbx1);
            this.tabPage1.Controls.Add(this.L_hbx1);
            this.tabPage1.Controls.Add(this.rTB_hbx1);
            this.tabPage1.Controls.Add(this.tb_hbx1);
            this.tabPage1.Controls.Add(this.btn_hbx1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(674, 228);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "HBX1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // b_hbx1
            // 
            this.b_hbx1.Location = new System.Drawing.Point(593, 12);
            this.b_hbx1.Name = "b_hbx1";
            this.b_hbx1.Size = new System.Drawing.Size(75, 23);
            this.b_hbx1.TabIndex = 7;
            this.b_hbx1.Text = "立即執行";
            this.b_hbx1.UseVisualStyleBackColor = true;
            this.b_hbx1.Click += new System.EventHandler(this.b_hbx1_Click);
            // 
            // L_hbx1
            // 
            this.L_hbx1.AutoSize = true;
            this.L_hbx1.Location = new System.Drawing.Point(458, 18);
            this.L_hbx1.Name = "L_hbx1";
            this.L_hbx1.Size = new System.Drawing.Size(18, 12);
            this.L_hbx1.TabIndex = 6;
            this.L_hbx1.Text = "L1";
            // 
            // btn_hbx1
            // 
            this.btn_hbx1.AutoSize = true;
            this.btn_hbx1.Location = new System.Drawing.Point(6, 18);
            this.btn_hbx1.Name = "btn_hbx1";
            this.btn_hbx1.Size = new System.Drawing.Size(35, 12);
            this.btn_hbx1.TabIndex = 3;
            this.btn_hbx1.Text = "HBX1";
            // 
            // richtb_status
            // 
            this.richtb_status.Location = new System.Drawing.Point(12, 281);
            this.richtb_status.Name = "richtb_status";
            this.richtb_status.ReadOnly = true;
            this.richtb_status.Size = new System.Drawing.Size(678, 101);
            this.richtb_status.TabIndex = 26;
            this.richtb_status.Text = "";
            // 
            // b_hbx9
            // 
            this.b_hbx9.Controls.Add(this.tabPage1);
            this.b_hbx9.Controls.Add(this.tabPage2);
            this.b_hbx9.Controls.Add(this.tabPage3);
            this.b_hbx9.Controls.Add(this.tabPage4);
            this.b_hbx9.Controls.Add(this.tabPage5);
            this.b_hbx9.Controls.Add(this.tabPage6);
            this.b_hbx9.Controls.Add(this.tabPage8);
            this.b_hbx9.Controls.Add(this.tabPage9);
            this.b_hbx9.Controls.Add(this.tabPage7);
            this.b_hbx9.Location = new System.Drawing.Point(12, 25);
            this.b_hbx9.Name = "b_hbx9";
            this.b_hbx9.SelectedIndex = 0;
            this.b_hbx9.Size = new System.Drawing.Size(682, 254);
            this.b_hbx9.TabIndex = 25;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.b_stc1);
            this.tabPage7.Controls.Add(this.L_stc1);
            this.tabPage7.Controls.Add(this.label7);
            this.tabPage7.Controls.Add(this.rTB_stc1);
            this.tabPage7.Controls.Add(this.tb_STC1);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(674, 228);
            this.tabPage7.TabIndex = 9;
            this.tabPage7.Text = "STC-1";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // b_stc1
            // 
            this.b_stc1.Location = new System.Drawing.Point(593, 12);
            this.b_stc1.Name = "b_stc1";
            this.b_stc1.Size = new System.Drawing.Size(75, 23);
            this.b_stc1.TabIndex = 14;
            this.b_stc1.Text = "立即執行";
            this.b_stc1.UseVisualStyleBackColor = true;
            this.b_stc1.Click += new System.EventHandler(this.b_stc1_Click);
            // 
            // L_stc1
            // 
            this.L_stc1.AutoSize = true;
            this.L_stc1.Location = new System.Drawing.Point(458, 18);
            this.L_stc1.Name = "L_stc1";
            this.L_stc1.Size = new System.Drawing.Size(23, 12);
            this.L_stc1.TabIndex = 13;
            this.L_stc1.Text = "stc1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "STC-1";
            // 
            // rTB_stc1
            // 
            this.rTB_stc1.Location = new System.Drawing.Point(8, 43);
            this.rTB_stc1.Name = "rTB_stc1";
            this.rTB_stc1.ReadOnly = true;
            this.rTB_stc1.Size = new System.Drawing.Size(660, 177);
            this.rTB_stc1.TabIndex = 7;
            this.rTB_stc1.Text = "";
            // 
            // tb_STC1
            // 
            this.tb_STC1.Location = new System.Drawing.Point(48, 11);
            this.tb_STC1.Name = "tb_STC1";
            this.tb_STC1.Size = new System.Drawing.Size(404, 22);
            this.tb_STC1.TabIndex = 6;
            this.tb_STC1.Text = "E:\\HBX_temp\\stcxdf\\";
            // 
            // btn_stop
            // 
            this.btn_stop.Image = ((System.Drawing.Image)(resources.GetObject("btn_stop.Image")));
            this.btn_stop.Location = new System.Drawing.Point(400, 386);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(68, 68);
            this.btn_stop.TabIndex = 24;
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(638, 399);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 55);
            this.button1.TabIndex = 28;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_clear1
            // 
            this.btn_clear1.Location = new System.Drawing.Point(584, -1);
            this.btn_clear1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_clear1.Name = "btn_clear1";
            this.btn_clear1.Size = new System.Drawing.Size(105, 18);
            this.btn_clear1.TabIndex = 29;
            this.btn_clear1.Text = "清除轉檔訊息";
            this.btn_clear1.UseVisualStyleBackColor = true;
            this.btn_clear1.Click += new System.EventHandler(this.btn_clear1_Click);
            // 
            // btn_clear2
            // 
            this.btn_clear2.Location = new System.Drawing.Point(584, 375);
            this.btn_clear2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_clear2.Name = "btn_clear2";
            this.btn_clear2.Size = new System.Drawing.Size(105, 18);
            this.btn_clear2.TabIndex = 30;
            this.btn_clear2.Text = "清除轉檔訊息";
            this.btn_clear2.UseVisualStyleBackColor = true;
            this.btn_clear2.Click += new System.EventHandler(this.btn_clear2_Click);
            // 
            // TB_count
            // 
            this.TB_count.Location = new System.Drawing.Point(179, 2);
            this.TB_count.Name = "TB_count";
            this.TB_count.Size = new System.Drawing.Size(48, 22);
            this.TB_count.TabIndex = 31;
            this.TB_count.Text = "60";
            this.TB_count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // HEAT_IMPORT_02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 483);
            this.Controls.Add(this.TB_count);
            this.Controls.Add(this.btn_clear2);
            this.Controls.Add(this.btn_clear1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.richtb_status);
            this.Controls.Add(this.b_hbx9);
            this.Controls.Add(this.btn_stop);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HEAT_IMPORT_02";
            this.Text = "XDF自動轉檔";
            this.Load += new System.EventHandler(this.HEAT_IMPORT_02_Load);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.b_hbx9.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.RichTextBox rTB_hbx6;
        private System.Windows.Forms.TextBox tb_hbx6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox rTB_hbx3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.RichTextBox rTB_hbx5;
        private System.Windows.Forms.TextBox tb_hbx5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox rTB_hbx1;
        private System.Windows.Forms.TextBox tb_hbx1;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.RichTextBox rTB_hbx8;
        private System.Windows.Forms.TextBox tb_hbx8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox rTB_hbx9;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TextBox tb_hbx9;
        private System.Windows.Forms.RichTextBox rTB_hbx4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox rTB_hbx2;
        private System.Windows.Forms.TextBox tb_hbx2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox tb_hbx3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_hbx4;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label btn_hbx1;
        private System.Windows.Forms.RichTextBox richtb_status;
        private System.Windows.Forms.TabControl b_hbx9;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_clear1;
        private System.Windows.Forms.Button btn_clear2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rTB_stc1;
        private System.Windows.Forms.TextBox tb_STC1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.Label L_hbx6;
        private System.Windows.Forms.Label L_hbx5;
        private System.Windows.Forms.Label L_hbx8;
        private System.Windows.Forms.Label L_hbx9;
        private System.Windows.Forms.Label L_hbx2;
        private System.Windows.Forms.Label L_hbx3;
        private System.Windows.Forms.Label L_hbx4;
        private System.Windows.Forms.Label L_hbx1;
        private System.Windows.Forms.Label L_stc1;
        private System.Windows.Forms.Button b_hbx6;
        private System.Windows.Forms.Button b_hbx5;
        private System.Windows.Forms.Button b_hbx8;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button b_hbx2;
        private System.Windows.Forms.Button b_hbx3;
        private System.Windows.Forms.Button b_hbx4;
        private System.Windows.Forms.Button b_hbx1;
        private System.Windows.Forms.Button b_stc1;
        private System.Windows.Forms.TextBox TB_count;
    }
}