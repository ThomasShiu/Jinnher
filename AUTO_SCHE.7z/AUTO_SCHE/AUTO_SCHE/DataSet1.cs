﻿

namespace AUTO_SCHE {
    
    
    public partial class DataSet1 {
    }
}
